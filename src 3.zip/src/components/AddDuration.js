import React, { useState } from 'react';

function TimeInput({ onClose, onUpdateStatus, setDurationValue, setOpenModal }) {
  const [selectedHour, setSelectedHour] = useState(null);
  const [selectedMinute, setSelectedMinute] = useState(null);

  const handleHourChange = (event) => {
    setSelectedHour(event.target.value);
  };

  const handleMinuteChange = (event) => {
    setSelectedMinute(event.target.value);
  };

  const handleSaveClick = () => {
    if (selectedHour !== null && selectedMinute !== null) {
      const formattedTime = `${selectedHour}:${selectedMinute}`;
      onUpdateStatus(formattedTime);
      setDurationValue(formattedTime);
    }
    setOpenModal(false);
  };

  return (
    <div>
      <h1>Select time:</h1>
      <select value={selectedHour} onChange={handleHourChange}>
        <option value={null}>--</option>
        {Array.from({ length: 13 }, (_, i) => (
          <option key={i} value={i.toString().padStart(2, '0')}>
            {i.toString().padStart(2, '0')}
          </option>
        ))}
      </select>
      :
      <select value={selectedMinute} onChange={handleMinuteChange}>
        <option value={null}>--</option>
        {Array.from({ length: 12 }, (_, i) => (
          <option key={i * 5} value={(i * 5).toString().padStart(2, '0')}>
            {(i * 5).toString().padStart(2, '0')}
          </option>
        ))}
      </select>
      <button onClick={handleSaveClick}>Save</button>
      <button onClick={onClose}>Close</button>
    </div>
  );
}

export default TimeInput;
