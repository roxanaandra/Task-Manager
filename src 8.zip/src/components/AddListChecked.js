import React, { useState, useEffect } from 'react';
import check from './images/assets/check.svg';

const AddListChecked = ({ value, task, onUpdateStatus }) => {
  const { id, title, status, edited_at, newTitle, newStatus } = task;
  const [statusInput, setStatusInput] = useState(status);

  const checkedInputHandler = () => {
    const newStatus = statusInput === 'To Do' ? 'Done' : 'To Do';
    setStatusInput(newStatus);
    

    const updatedTask = { ...task, newStatus: newStatus };
    onUpdateStatus(updatedTask);

    console.log(newStatus);
  };



  return (
    <>
    <div className='list_checked'>
      <div>
        <button className='checkbox_round' onClick={checkedInputHandler}>
          {statusInput === 'Done' && <img src={check} alt="Check" width="15px" />}
        </button>
      </div>
      <div>
        <input
          type="text"
          value={value}
          style={{ textDecoration: statusInput === 'Done' ? 'line-through' : 'none' }}
          readOnly
          className='input_list'
        />
      </div>
    </div>
    </>
  );
};

export default AddListChecked;
