import React, { useState, useRef, useEffect } from 'react';
import AddListChecked from './AddListChecked';

const AddList = ({task, onUpdateStatus}) => {
  const [listInput, setListInput] = useState('');
  const inputRef = useRef(null);
  const [inputs, setInputs] = useState([]);

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault(); 
      setInputs([...inputs, listInput]);
      onUpdateStatus(inputs);
      setListInput('');
    }
  };

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);

  return (
    <>
      <div>
        <input
          type="text"
          value={listInput}
          onChange={(e) => setListInput(e.target.value)}
          ref={inputRef}
          onKeyDown={handleKeyDown}
          autoComplete="off" 
          className='input_list'
        />
      </div>
      <div>
        {inputs.map((value, index) => (
          <AddListChecked key={index} value={value} task={task} onUpdateStatus={onUpdateStatus}/>
        ))}
      </div>
    </>
  );
};

export default AddList;
