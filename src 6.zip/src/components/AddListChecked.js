import React, { useState } from 'react';
import check from './images/assets/check.svg';
import flag from './images/assets/flag.svg';

const AddListChecked = ({ onUpdateStatus, task, valueInput }) => {
    const { id, title, status, edited_at } = task;
    const [isChecked, setIsChecked] = useState(status === 'Done');

    const updateStatusHandler = () => {
        // Toggle the isChecked state and update the status accordingly
        setIsChecked(!isChecked);
        const newStatus = isChecked ? 'To do' : 'Done';
        onUpdateStatus(newStatus);
    };

    const textStyles = {
        textDecoration: isChecked ? 'line-through' : 'none',
    };

    return (
        <div>
            <div className='list_checked'>
                <div>
                    <button className='checkbox_round' onClick={updateStatusHandler}>
                        <img src={isChecked ? check : null} width="15px" className='image_addlistchecked' />
                    </button>
                </div>
                <div>
                    <input
                        type="text"
                        className='input_addlist'
                        value={valueInput}
                        placeholder="Add a task..."
                        style={textStyles}
                    />
                </div>
            </div>
        </div>
    );
};

export default AddListChecked;
