import React, { useRef, useState, useEffect } from 'react';
import AddListChecked from './AddListChecked';

const AddList = ({onUpdateStatus, task}) => {
    const inputRef = useRef(null);
    const [inputList, setInputList] = useState([]);
    const [valueInput, setValueInput] = useState('');
    const [newInput, setNewInput] = useState('');

    useEffect(() => {
        if (inputRef.current) {
            inputRef.current.focus();
        }

        const handleKeyPress = (event) => {
            if (event.key === 'Enter') {
                const newInputList = [...inputList, valueInput];
                setInputList(newInputList);
                setValueInput('');

                
                if (inputRef.current) {
                    inputRef.current.focus();
                }
                onUpdateStatus(valueInput);
            }
        };

        inputRef.current.addEventListener('keypress', handleKeyPress);

        return () => {
            if (inputRef.current) {
                inputRef.current.removeEventListener('keypress', handleKeyPress);
            }
        };
    }, [inputList, valueInput]);

    const inputChangeHandler = () => {
        if (inputRef.current) {
            setValueInput(inputRef.current.value);
        }
    }

    return (
        <>
            <div>
                <input
                    ref={inputRef}
                    type="text"
                    value={valueInput}
                    onChange={inputChangeHandler}
                    className='input_list'
                />
            </div>
            <div>
                {inputList.map((valueInput, index) => (
                    <AddListChecked
                        key={index.id}
                        type="text"
                        value={valueInput}
                        onUpdateStatus={onUpdateStatus}
                        task={task}
                        valueInput={valueInput}
                    />
                ))}
            </div>
        </>
    )
}

export default AddList;
