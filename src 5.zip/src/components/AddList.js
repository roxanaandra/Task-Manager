import React, { useRef, useState, useEffect } from 'react';

const AddList = () => {
    const inputRef = useRef(null);
    const [inputList, setInputList] = useState([]);
    const [valueInput, setValueInput] = useState('');
    const [newInput, setNewInput] = useState('');

    useEffect(() => {
        if (inputRef.current) {
            inputRef.current.focus();
        }

        const handleKeyPress = (event) => {
            if (event.key === 'Enter') {
                const newInputList = [...inputList, valueInput];
                setInputList(newInputList);
                setValueInput('');

                // Focus pe noul câmp de intrare creat
                if (inputRef.current) {
                    inputRef.current.focus();
                }
            }
        };

        inputRef.current.addEventListener('keypress', handleKeyPress);

        return () => {
            if (inputRef.current) {
                inputRef.current.removeEventListener('keypress', handleKeyPress);
            }
        };
    }, [inputList, valueInput]);

    const inputChangeHandler = () => {
        if (inputRef.current) {
            setValueInput(inputRef.current.value);
        }
    }

    return (
        <>
            <div>
                <input
                    ref={inputRef}
                    type="text"
                    value={valueInput}
                    onChange={inputChangeHandler}
                    placeholder="subtask"
                    className='input_addlist'
                />
            </div>
            <div>
                {inputList.map((inputValue, index) => (
                    <input
                        key={index}
                        type="text"
                        value={inputValue}
                        readOnly
                        onChange={(e)=> setNewInput(e.target.value)}
                        className='input_list'
                    />
                ))}
            </div>
        </>
    )
}

export default AddList;
